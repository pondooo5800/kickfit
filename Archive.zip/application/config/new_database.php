<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

include(APPPATH. '/config/database.php');
$config['new_db'] = $db['default'];

/* End of file new_database.php */
/* Location: ./application/config/database.php */